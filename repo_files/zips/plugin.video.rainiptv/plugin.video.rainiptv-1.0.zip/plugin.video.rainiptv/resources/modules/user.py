import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnJhaW5pcHR2')

name = b.b64decode('UmFpbklQVFY=')

host = b.b64decode('aHR0cDovL2ZsYXdsZXNzLWlwdHYubmV0')

port = b.b64decode('NDU0NQ==')